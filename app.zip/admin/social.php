<?php

class Social extends PHPFrodo
{

    private $user_login;
    private $user_id;
    private $user_name;
    private $user_level;

    public function __construct()
    {
        parent::__construct();
        $sid = new Session;
        $sid->start();
        if ( !$sid->check() || $sid->getNode( 'user_id' ) <= 0 )
        {
            $this->redirect( "$this->baseUri/admin/login/logout/" );
            exit;
        }
        $this->user_login = $sid->getNode( 'user_login' );
        $this->user_id = $sid->getNode( 'user_id' );
        $this->user_name = $sid->getNode( 'user_name' );
        $this->user_level = ( int ) $sid->getNode( 'user_level' );
        $this->assign( 'user_name', $this->user_name );
        $this->select()
                ->from( 'config' )
                ->execute();
        if ( $this->result() )
        {
            $this->config = ( object ) $this->data[0];
            $this->assignAll();
        }
        if ( isset( $this->uri_segment ) && in_array( 'process-ok', $this->uri_segment ) )
        {
            $this->assign( 'msgOnload', 'notify("<h1>Procedimento realizado com sucesso</h1>")' );
        }
        if ( $this->user_level == 1 ) {
            $this->assign('showhide','hide');
        }         
    }

    public function welcome()
    {
        $this->tpl( 'admin/social.html' );
        $this->select()->from( 'social' )->execute();
        if ( $this->result() )
        {
            $this->map( $this->data[0] );
            $this->assignAll();
        }
        $this->render();
    }

    public function atualizar()
    {
        if ( isset( $_POST['config_site_social'] ) && !empty( $_POST['config_site_social'] ) )
        {
            $plugin = $_POST['config_site_social'];
            $plugin = addslashes( preg_replace( '/\s+/', ' ', $plugin ) );
            $this->update( 'config' )->set( array( 'config_site_social' ), array( "$plugin" ) )->execute();
        }

        $this->redirect( "$this->baseUri/admin/social/process-ok/" );
    }

    public function restore()
    {
        $plugin = '<span class="st_facebook_large" displayText="Facebook"></span> 
              <span class="st_twitter_large" displayText="Tweet"></span> 
              <span class="st_googleplus_large" displayText="Google +"></span> 
              <span class="st_linkedin_large" displayText="LinkedIn"></span> 
              <span class="st_pinterest_large" displayText="Pinterest"></span> 
              <span class="st_evernote_large" displayText="Evernote"></span> 
              <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script> 
              <script type="text/javascript">stLight.options({publisher: "7f061e38-a881-40ec-922d-4d9fe4b8a543"});</script>';
        $plugin = addslashes( preg_replace( '/\s+/', ' ', $plugin ) );
        $this->update( 'config' )->set( array( 'config_site_social' ), array( "$plugin" ) )->execute();
        $this->redirect( "$this->baseUri/admin/social/process-ok/" );
    }


    public function atualizarfb()
    {
        if ( isset( $_POST['social_fb'] ) && !empty( $_POST['social_fb'] ) )
        {
            $plugin = $_POST['social_fb'];
            $plugin = addslashes( preg_replace( '/\s+/', ' ', $plugin ) );
            $this->update( 'social' )->set( array( 'social_fb' ), array( "$plugin" ) )->execute();
        }
        $this->redirect( "$this->baseUri/admin/social/process-ok/" );
    }    
    
}

/*end file*/