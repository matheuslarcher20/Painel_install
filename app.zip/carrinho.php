<?php

class Carrinho extends PHPFrodo
{
    public $config = array( );
    public $menu = null;
    public $item_categoria = null;
    public $item_sub = null;
    public $item_url = null;
    public $item_id = null;
    public $item = null;
    public $login = null;
    public $cart = array( );
    public $f_foto = null;
    public $total_compra = 0;
    public $total_compra_no_frete = 0;
    public $cliente_id;
    public $cliente_cep = null;
    public $cliente_nome;
    public $cliente_email;
    public $valor_frete = 0;
    public $prazo_frete = 0;
    public $pedido_total_frete;
    public $pedido_id = 0;
    public $last_pedido_id = 0;
    public $fatura_link = 0;
    public $itens_da_fatura;
    public $pedido_endereco;
    public $qtde_item = -1;
    public $estoque = 0;

    public function __construct()
    {
        parent:: __construct();
        $this->login = null;
        $sid = new Session;
        $sid->start();
        if ( $sid->check() && $sid->getNode( 'cliente_id' ) >= 1 )
        {
            $this->cliente_email = ( string ) $sid->getNode( 'cliente_email' );
            $this->cliente_id = $sid->getNode( 'cliente_id' );
            $this->cliente_nome = ( string ) $sid->getNode( 'cliente_nome' );
            $this->cliente_cep = $sid->getNode( 'cliente_cep' );
            $this->login = array(
                'cliente_email' => "$this->cliente_email",
                'cliente_nome' => "$this->cliente_nome",
                'cliente_id' => "$this->cliente_id",
            );
            //$this->assign( 'cliente_nome', "&nbsp;$this->cliente_nome" );
            $this->assign( 'cliente_nome', current( explode( ' ', $this->cliente_nome ) ) );
            $this->assign( 'cliente_email', $this->cliente_email );
            $this->assign( 'cliente_cep', $this->cliente_cep );
            $this->assign( 'onload', 'freteReload()' );
            $this->assign( 'cliente_msg', 'acesse aqui sua conta.' );
            $this->assign( 'urlPedido', "$this->baseUri/carrinho/incluirPedido/" );
            $this->assign( 'logged', 'true' );
            $this->assign( 'showHide', 'show' );
        }
        else
        {
            $this->assign( 'showHide', 'hidden' );
            $this->assign( 'cliente_nome', "" );
            $this->assign( 'cliente_msg', 'fa�a seu login ou cadastre-se.' );
            $this->assign( 'urlPedido', "$this->baseUri/cliente/login/" );
            $this->assign( 'logged', 'false' );
        }
        $this->select()
                ->from( 'config' )
                ->execute();
        if ( $this->result() )
        {
            $this->map( $this->data[0] );
            $this->config = ( object ) $this->data[0];
            $this->assignAll();
        }
    }

    public function show()
    {
        $this->printr( $_SESSION );
        exit;
    }

    public function welcome()
    {
        $this->tpl( 'public/carrinho.html' );
        $this->getLastCep();
        $this->getTotal();
        $this->getCarrinho();
        $this->getMenuFooter();
        $this->render();
    }

    public function getLastCep()
    {
        if ( isset( $_SESSION['mycep'] ) )
        {
            $this->assign( 'mycep', $_SESSION['mycep'] );
        }
        if ( isset( $_SESSION['mycep_frete'] ) )
        {
            if ( $_SESSION['mycep_frete'] == '0.00' )
            {
                $this->assign( 'mycep_frete', 'Frete Gr�tis' );
            }
            else
            {
                $this->assign( 'mycep_frete', 'R$ ' . preg_replace( '/\./', ',', $_SESSION['mycep_frete'] ) );
            }
        }
    }

    public function getCarrinho()
    {
        if ( isset( $_SESSION['cart'] ) && count( $_SESSION['cart'] ) >= 1 )
        {
            $this->qtde_item = count( $_SESSION['cart'] );
            $this->data = $_SESSION['cart'];
            $this->money( 'item_preco' );
            $this->money( 'valor_total' );
            $this->cut( 'item_title', 75, '...' );
            /*
              foreach ( $this->data as $k => $v )
              {
              //$this->data[$k]['valor_total'] = $this->data[$k]['item_preco'] * $this->data[$k]['item_qtde'];
              }
             */
            $this->fetch( 'cart', $this->data );
            $this->assign( 'showCheckout', '' );
            $this->assign( 'showEmptyCart', 'hidden' );
            $this->assign( 'cartTotal', "R$ " . $this->total_compra );
        }
        else
        {
            $this->clear();
            $this->assign( 'msg_carrinho_vazio', 'SEU CARRINHO EST� VAZIO!' );
            $this->assign( 'cartTotal', "R$ 0,00" );
            $this->assign( 'showCheckout', 'hide' );
            $this->assign( 'showEmptyCart', 'showin' );
        }
    }

    public function nCalculo()
    {
        if ( isset( $_SESSION['cart'] ) )
        {
            $this->data = $_SESSION['cart'];
            $this->money( 'item_preco' );
            $this->money( 'valor_total' );
            $this->cut( 'item_title', 90, '...' );
            $calcula = false;
            $max = 0;
            foreach ( $this->data as $d )
            {
                if ( $d['item_peso'] > $max )
                {
                    $max = $d['item_peso'];
                    $lid = $d['item_id'];
                    $p = $d['item_peso'] * $d['item_qtde'];
                    $a = $d['item_altura'];
                    $l = $d['item_largura'];
                    $c = $d['item_comprimento'];
                    $t = $this->total_compra;
                }
                if ( $d['item_calcula_frete'] == 2 )
                {
                    $calcula = true;
                }
            }
            if ( $calcula == true )
            {
                echo "{\"p\":\"$p\",\"a\":\"$a\",\"l\":\"$l\",\"c\":\"$c\",\"t\":\"$t\",\"cf\":\"sim\"}";
            }
            else
            {
                echo "{\"p\":\"$p\",\"a\":\"$a\",\"l\":\"$l\",\"c\":\"$c\",\"t\":\"$t\",\"cf\":\"nao\"}";
            }
        }
        else
        {
            echo "{\"p\":\"-1\"}";
        }
    }

    public function nFormata()
    {

        if ( isset( $_POST['v1'] ) )
        {
            $_SESSION['mycep_frete'] = $_POST['v1']; //valor frete
            $this->getTotal();
            echo  $this->total_compra;
        }
        else
        {
            $this->getTotal();
            echo $this->total_compra;
        }
        //prazo entrega
        if ( isset( $_POST['v2'] ) && $_POST['v2'] != "" )
        {
            if($_POST['v2'] >= 2 ){
                $_SESSION['mycep_prazo'] = '1 � ' . $_POST['v2'] . ' dias �teis ';
            }else{
                $_SESSION['mycep_prazo'] = '1 dia �til ';                
            }
        }
        //tipo entrega
        if ( isset( $_POST['v3'] ) && $_POST['v3'] != "")
        {
            $_SESSION['mycep_tipo_frete'] = " (". $_POST['v3'] .  ") ";
        }
    }

    public function getEstoque()
    {
        $this->select()
                ->from( 'item' )
                ->where( "item_id = $this->item_id" )
                ->execute();
        if ( $this->result() )
        {
            $this->estoque = $this->data[0]['item_estoque'] + 1;
        }
        else
        {
            $this->estoque = 0;
        }
    }

    public function adicionar()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $this->item_id = $this->uri_segment[2];
            //if ( $this->getItem() != false ){
            $strAtrrPed = "";
            $strAttr = "";
            if ( isset( $_POST['attr'] ) && !empty( $_POST['attr'] ) )
            {
                $attr = array( );
                $i = 0;
                foreach ( $_POST['attr'] as $k => $v )
                {
                    $attr[$i]['atributo'] = $v['name'];
                    $attr[$i]['item'] = $v['value'];
                    $i++;
                }
                $atributos = array( );
                foreach ( $attr as $at )
                {
                    $attGet = $this->getAttr( $at['item'] );
                    $atributos[] = $attGet;
                    $strAtrrPed .= $attGet[1] . " - ";
                }
                $strAtrrPed = substr( $strAtrrPed, 0, -2 );
                $strAttr = array( );
                foreach ( $atributos as $at )
                {
                    $strAttr[] = implode( ",", $at );
                }
                $strAttr = implode( "|", $strAttr );
            }
            if ( isset( $_POST['id'] ) && !empty( $_POST['id'] ) )
            {
                $this->cart_id = base64_encode( uniqid( md5( time() ) ) );
                if ( $this->checkItemCart( $strAtrrPed ) == false )
                {
                    $this->item_id = $_POST['id'];
                    if ( $this->getItem() )
                    {
                        $this->cart[$this->cart_id] = $this->item;
                        $_SESSION['cart'][$this->cart_id] = $this->item;
                        $t = $_SESSION['cart'][$this->cart_id]['item_preco'] * $_SESSION['cart'][$this->cart_id]['item_qtde'];
                        $_SESSION['cart'][$this->cart_id]['valor_total'] = ( string ) $t;
                        $_SESSION['cart'][$this->cart_id]['atributos'] = ( string ) $strAttr;
                        $_SESSION['cart'][$this->cart_id]['atributo_ped'] = ( string ) $strAtrrPed;
                        $_SESSION['cart'][$this->cart_id]['cart_id'] = ( string ) $this->cart_id;
                        $_SESSION['cart'][$this->cart_id]['item_id'] = ( string ) $this->item_id;
                        $_SESSION['cart'][$this->cart_id]['item_estoque'] = ( string ) $this->estoque;
                        $_SESSION['cart'][$this->cart_id]['item_estoque']--;
                    }
                }
                else
                {
                    $_SESSION['cart'][$this->cart_id]['item_qtde']++;
                    $t = $_SESSION['cart'][$this->cart_id]['item_preco'] * $_SESSION['cart'][$this->cart_id]['item_qtde'];
                    $_SESSION['cart'][$this->cart_id]['valor_total'] = $t;
                }
            }
            //}
        }
    }

    public function checkItemCart( $strAtrrPed = "" )
    {
        $incart = false;
        if ( isset( $_SESSION['cart'] ) && count( $_SESSION['cart'] ) >= 1 )
        {
            foreach ( $_SESSION['cart'] as $k => $v )
            {
                if ( isset( $_SESSION['cart'][$k]['item_id'] ) && $_SESSION['cart'][$k]['item_id'] == $this->item_id )
                {
                    if ( isset( $_SESSION['cart'][$k]['atributo_ped'] ) )
                    {
                        if ( $_SESSION['cart'][$k]['atributo_ped'] == $strAtrrPed )
                        {
                            $this->cart_id = $_SESSION['cart'][$k]['cart_id'];
                            $incart = true;
                        }
                    }
                }
            }
        }
        return $incart;
    }

    public function getAttr( $iattr_id )
    {
        $this->select()
                ->from( 'atributo' )
                ->join( 'iattr', 'iattr_atributo = atributo_id' )
                ->where( "iattr_id = $iattr_id" )
                ->execute();
        if ( $this->result() )
        {
            return array( $this->data[0]['atributo_nome'], $this->data[0]['iattr_nome'], $this->data[0]['atributo_id'], $this->data[0]['iattr_id'] );
        }
    }

    public function getItemUrl()
    {
        if ( $this->item_id != null )
        {
            $this->select()
                    ->from( 'item' )
                    ->join( 'sub', 'item_sub = sub_id', 'INNER' )
                    ->join( 'categoria', 'sub_categoria = categoria_id', 'INNER' )
                    ->where( "item_id = $this->item_id" )
                    ->execute();
            if ( $this->result() )
            {
                $this->data[0]['item_qtde'] = 1;
                $this->data[0]['full_url'] = "$this->baseUri/produto/"
                        . $this->data[0]['categoria_url'] . "/"
                        . $this->data[0]['sub_url'] . "/"
                        . $this->data[0]['item_url'] . "/"
                        . $this->data[0]['item_id'] . "/";
                return $this->data[0]['full_url'];
            }
            else
            {
                return "$this->baseUri/";
            }
        }
    }

    public function getItem()
    {
        if ( $this->item_id != null )
        {
            $this->select()
                    ->from( 'item' )
                    ->join( 'sub', 'item_sub = sub_id', 'INNER' )
                    ->join( 'categoria', 'sub_categoria = categoria_id', 'INNER' )
                    ->where( "item_id = $this->item_id" )
                    ->execute();
            if ( $this->result() )
            {
                $this->estoque = $this->data[0]['item_estoque'];
                $this->addkey( 'item_bread_title', '', 'item_title' );
                $this->cut( 'item_bread_title', 50, '...' );
                //desconto
                $item_desconto = $this->data[0]['item_desconto'];
                if ( $item_desconto > 1 )
                {
                    $desconto = ($this->data[0]['item_preco'] - $this->data[0]['item_desconto'] );
                    $this->data[0]['item_valor_original'] = @number_format( $this->data[0]['item_preco'], 2, ",", "." );
                    $this->data[0]['item_desconto'] = preg_replace( '/,/', '.', $this->data[0]['item_desconto'] );
                    $this->data[0]['item_preco'] = $desconto;
                    $this->data[0]['showhide_valorOri'] = 'showv';
                }
                else
                {
                    $this->data[0]['item_valor_original'] = '';
                    $this->data[0]['showhide_valorOri'] = 'hide';
                }

                //parcelamento
                $item_parc = $this->data[0]['item_parc'];
                if ( $item_parc > 1 )
                {
                    $item_valor_parc = ceil( (($this->data[0]['item_preco']) / $item_parc ) );
                    $item_valor_parc = @number_format( $item_valor_parc, 2, ",", "." );
                    $item_valor_parc = "$item_parc x $item_valor_parc";
                    $this->data[0]['item_valor_parc'] = $item_valor_parc;
                }

                unset( $this->data[0]['item_desc'] );
                $this->data[0]['item_qtde'] = 1;
                $this->data[0]['full_url'] = "$this->baseUri/produto/"
                        . $this->data[0]['categoria_url'] . "/"
                        . $this->data[0]['sub_url'] . "/"
                        . $this->data[0]['item_url'] . "/"
                        . $this->data[0]['item_id'] . "/";
                $this->item = $this->data[0];
                $this->item['item_foto'] = $this->fillFoto();
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public function incrementa()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $this->cart_id = $this->uri_segment[2];
            if ( isset( $_SESSION['cart'][$this->cart_id]['item_id'] ) )
            {
                if ( $_SESSION['cart'][$this->cart_id]['item_estoque'] >= 1 )
                {
                    $_SESSION['cart'][$this->cart_id]['item_qtde']++;
                    $t = $_SESSION['cart'][$this->cart_id]['item_preco'] * $_SESSION['cart'][$this->cart_id]['item_qtde'];
                    $_SESSION['cart'][$this->cart_id]['valor_total'] = $t;
                    $total = number_format( $_SESSION['cart'][$this->cart_id]['valor_total'], 2, ',', '.' );
                    $qtde = $_SESSION['cart'][$this->cart_id]['item_qtde'];
                    $this->getTotal();
                    $this->estoque = $_SESSION['cart'][$this->cart_id]['item_estoque'];
                    echo "{\"total\":\"$total\",\"qtde\":\"$qtde\",\"total_compra\":\"$this->total_compra\",\"estoque\":\"$this->estoque\"}";
                    $_SESSION['cart'][$this->cart_id]['item_estoque']--;
                }
                else
                {
                    //$_SESSION['cart'][$this->cart_id]['item_estoque'] = 0;
                    echo "{\"estoque\":\"0\"}";
                }
            }
        }
    }

    public function decrementa()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $this->cart_id = $this->uri_segment[2];
            if ( isset( $_SESSION['cart'][$this->cart_id] ) )
            {
                $_SESSION['cart'][$this->cart_id]['item_qtde']--;
                $t = $_SESSION['cart'][$this->cart_id]['item_preco'] * $_SESSION['cart'][$this->cart_id]['item_qtde'];
                $_SESSION['cart'][$this->cart_id]['valor_total'] = $t;
                $total = number_format( $_SESSION['cart'][$this->cart_id]['valor_total'], 2, ',', '.' );
                $qtde = $_SESSION['cart'][$this->cart_id]['item_qtde'];
                if ( $_SESSION['cart'][$this->cart_id]['item_qtde'] == 0 )
                {
                    unset( $_SESSION['cart'][$this->cart_id] );
                }
                $this->getTotal();
                $itens_carrinho = count( $_SESSION['cart'] );
                $_SESSION['cart'][$this->cart_id]['item_estoque']++;
                $this->estoque = $_SESSION['cart'][$this->cart_id]['item_estoque'];
                echo "{\"total\":\"$total\",\"qtde\":\"$qtde\",\"total_compra\":\"$this->total_compra\",\"itens\":\"$itens_carrinho\",\"estoque\":\"$this->estoque\"}";
            }
            else
            {
                echo "{\"total\":\"0,00\",\"qtde\":\"0\",\"total_compra\":\"0,00\",\"itens\":\"0\",\"estoque\":\"$this->estoque\"}";
            }
        }
    }

    public function clear()
    {
        if ( isset( $_SESSION['cart'] ) )
        {
            $_SESSION['cart'] = null;
            unset( $_SESSION['cart'] );
            $this->assign( 'mybasket', 'icon-basket' );
            $this->assign( 'qtdeItem', '0' );
        }
        if ( isset( $_SESSION['mycep_frete'] ) )
        {
            unset( $_SESSION['mycep_frete'] );
        }
        if ( isset( $_SESSION['mycep'] ) )
        {
            unset( $_SESSION['mycep'] );
        }
        if ( isset( $_SESSION['mycep_prazo'] ) )
        {
            unset( $_SESSION['mycep_prazo'] );
        }
        if ( isset( $_SESSION['finaliza-entrega'] ) )
        {
            unset( $_SESSION['finaliza-entrega'] );
        }
        if ( isset( $_SESSION['mycep_entrega'] ) )
        {
            unset( $_SESSION['mycep_entrega'] );
        }
        if ( isset( $_SESSION['finaliza-pagamento'] ) )
        {
            unset( $_SESSION['finaliza-pagamento'] );
        }
        if ( isset( $this->uri_segment[2] ) )
        {
            $this->redirect( "$this->baseUri/carrinho/" );
        }
    }

    public function remove()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $this->cart_id = $this->uri_segment[2];
            if ( isset( $_SESSION['cart'][$this->cart_id] ) )
            {
                $_SESSION['cart'][$this->cart_id]['item_estoque']--;
                unset( $_SESSION['cart'][$this->cart_id] );
                $this->getTotal();
            }
            if ( !isset( $this->uri_segment[3] ) )
            {
                $this->redirect( "$this->baseUri/carrinho/" );
            }
            else
            {
                echo $this->total_compra;
            }
        }
    }

    public function getTotal()
    {
        $this->total_compra = 0;
        if ( isset( $_SESSION['cart'] ) && count( $_SESSION['cart'] ) >= 1 )
        {
            $this->cart = $_SESSION['cart'];
            foreach ( $this->cart as $k => $v )
            {
				if(isset( $this->cart[$k]['item_preco']) && isset( $this->cart[$k]['item_qtde']))
				{
					$this->total_compra += ( float ) $this->cart[$k]['item_preco'] * ( int ) $this->cart[$k]['item_qtde'];
				}
            }
            $this->total_compra_no_frete = @number_format( $this->total_compra, 2, ",", "." );
            if ( isset( $_SESSION['mycep_frete'] ) && $_SESSION['mycep_frete'] != '0.00' )
            {
                $this->total_compra = $this->total_compra + preg_replace( '/,/', '.', $_SESSION['mycep_frete'] );
            }
            $this->total_compra = @number_format( $this->total_compra, 2, ",", "." );
        }
    }

    public function fillFoto()
    {
        $this->select()
                ->from( 'foto' )
                ->where( "foto_item = $this->item_id" )
                ->orderby( 'foto_pos asc' )
                ->execute();
        if ( $this->result() )
        {
            $this->preg( '/\.jpg/', '', 'foto_url' );
            return $this->data[0]['foto_url'];
        }
    }

    public function getMenuFooter()
    {
        $this->menu = new Menu;
        $this->fetch( 'f', $this->menu->getFooter() );
    }
    
    public function double( $str )
    {
        return preg_replace( '/,/', '.', $str );
    }    
}
