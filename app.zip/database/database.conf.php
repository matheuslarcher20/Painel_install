<?php

# Configura��o dos bancos de dados suportados no PDO
$databases = array(
    # MYSQL
    'default' => array
        (
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'braga_14',
        'user' => 'braga_14',
        'password' => '123mudar',
        'emailAdmin' => 'seusitehoje@gmail.com'
    )
);

/* end file */