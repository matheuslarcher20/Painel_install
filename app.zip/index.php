<?php

@header( "Cache-Control: max-age=604800" );

class Index extends PHPFrodo
{
    public $config = array( );
    public $menu;
    public $condition;
    public $page_active = null;
    public $categoria_title;
    public $sub_title;
    public $sid;
    public $message_bar = "Produtos em Destaque";
    public $slide_qtde_itens_mais_vistos = 5;
    public $slide_qtde_itens_novos = 5;

    public function __construct()
    {
        parent:: __construct();

        $this->sid = new Session;
        $this->sid->start();
        if ( $this->sid->check() && $this->sid->getNode( 'cliente_id' ) >= 1 )
        {
            $this->cliente_email = ( string ) $this->sid->getNode( 'cliente_email' );
            $this->cliente_id = $this->sid->getNode( 'cliente_id' );
            $this->cliente_nome = ( string ) $this->sid->getNode( 'cliente_nome' );
            $this->assign( 'cliente_nome', current( explode( ' ', $this->cliente_nome ) ) );
            $this->assign( 'cliente_email', $this->cliente_email );
            $this->assign( 'cliente_msg', 'acesse aqui sua conta.' );
            $this->assign( 'logged', 'true' );
        }
        else
        {
            $this->assign( 'cliente_msg', 'fa�a seu login ou cadastre-se.' );
            $this->assign( 'logged', 'false' );
        }
        //get all config site
        $this->select()
                ->from( 'config' )
                ->execute();
        if ( $this->result() )
        {
            $this->config = ( object ) $this->data[0];
            $this->sid->addNode( 'config_site_menu', $this->config->config_site_menu );
            $this->assignAll();
        }
        //initial condition for home itens
        $this->condition = 'item_destaque = 1 and item_show = 1 and item_estoque >= 1';
        $this->message_bar = "Produtos em Destaque";
        //get current category
        $this->getActiveCategory();
    }

    public function welcome()
    {
        $this->tpl( 'public/index.html' );
        if ( $this->page_active != null )
        {
            $this->tpl( 'public/index_sem_slide.html' );
        }
        //slideshow
        if ( $this->page_active == null )
        {
            $this->fillSlideShow();
        }
        //carrinho lateral
        $this->getCarrinho();
        //redes sociais footer
        $plug = new Social;
        $this->assign( 'social_fb', $plug->social_fb );
        $this->assign( 'social_tw', $plug->social_tw );
        $this->select()
                ->from( 'item' )
                ->join( 'sub', 'item_sub = sub_id', 'INNER' )
                ->join( 'categoria', 'sub_categoria = categoria_id', 'INNER' )
                ->join( 'foto', 'foto_item = item_id and foto.foto_pos = ( SELECT MIN( foto_pos ) FROM foto where foto_item = item_id)', 'LEFT' )
                ->where( $this->condition )
                ->paginate( 12 )
                ->groupby( 'item_id' )
                ->orderby( 'item_estoque desc, item_id desc' )
                ->execute();
        if ( $this->result() )
        {
            $this->categoria_title = $this->data[0]['categoria_title'];
            $this->sub_title = $this->data[0]['sub_title'];
            $data = $this->data;
            foreach ( $data as $k => $v )
            {
                //desconto
                $item_desconto = $data[$k]['item_desconto'];
                if ( $item_desconto > 1 )
                {
                    $data[$k]['item_valor_original'] = $data[$k]['item_preco'];
                    $data[$k]['item_preco'] = ($data[$k]['item_preco'] - $data[$k]['item_desconto']);
                    $data[$k]['item_valor_original'] = @number_format( $data[$k]['item_valor_original'], 2, ',', '.' );
                    $data[$k]['showHide'] = "";
                }
                else
                {
                    $data[$k]['item_valor_original'] = "";
                    $data[$k]['showHide'] = "hide";
                }
                //parcelamento
                $item_parc = $data[$k]['item_parc'];
                if ( $item_parc > 1 )
                {
                    $item_valor_parc = ceil( (($data[$k]['item_preco'] ) / $item_parc ) );
                    $item_valor_parc = @number_format( $item_valor_parc, 2, ",", "." );
                    $item_valor_parc = " $item_parc x de $item_valor_parc";
                    $data[$k]['item_valor_parc'] = $item_valor_parc;
                }
                else
                {
                    $data[$k]['item_valor_parc'] = "";
                }
                $data[$k]['item_preco'] = @number_format( $data[$k]['item_preco'], 2, ',', '.' );
                $data[$k]['foto_url'] = preg_replace( '/\.jpg/', '', $data[$k]['foto_url'] );
                $data[$k]['item_short_title'] = $data[$k]['item_title'];
				
                if ( $data[$k]['item_estoque'] <= 0 )
                {
                    $data[$k]['showHide'] = "hide";
                    $data[$k]['item_valor_original'] = "";
                    $data[$k]['item_valor_parc'] = "";
                    $data[$k]['item_preco'] = "Indispon�vel";
                }
                else
                {
                    $data[$k]['item_preco'] = "R$ " . $data[$k]['item_preco'];
                }
				
            }
            $this->data = $data;
            $this->cut( 'item_short_title', 80, '...' );
            $this->fetch( 'i', $this->data );
        }
        else
        {
            $this->assign( 'message_default', '<p> &nbsp; Nenhum produto dispon�vel!</p>' );
        }
        $this->getMenu();
        $this->getTitleBar();        
        $this->render();
    }

    public function promocoes()
    {
        //codicao para promocoes
        $this->condition = 'item_show = 1 and item_oferta = 1 and item_estoque >= 1';
        //$this->condition = 'foto_pos = 0 and item_show = 1';
        $this->page_active = 'promocoes';
        $this->message_bar = "Confira Nossas Promo��es";
        $this->welcome();
    }

    public function busca()
    {
        if ( isset( $_POST['busca'] ) && !empty( $_POST['busca'] ) )
        {
            $busca = trim( $_POST['busca'] );
            $this->assign( 'busca', "$busca" );
            //codicao para busca
            $this->condition = "foto_pos = 0 AND item_title like'%$busca%' AND item_show = 1 OR ";
            $this->condition .= "foto_pos = 0 AND item_keywords like'%$busca%' AND item_show = 1 OR ";
            $this->condition .= "foto_pos = 0 AND categoria_title like'%$busca%' AND item_show = 1 OR ";
            $this->condition .= "foto_pos = 0 AND sub_title like'%$busca%' AND item_show = 1";
            $this->message_bar = "Resultado da busca: $busca";
            $this->page_active = 'busca';
            $this->welcome();
        }
        else
        {
            $this->redirect( "$this->baseUri/" );
        }
    }

    public function categoria()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $categoria = $this->uri_segment[2];
            $this->pagebase = "$this->baseUri/index/categoria/$categoria";
            if ( isset( $this->uri_segment[3] ) )
            {
                $sub = $this->uri_segment[3];
                $this->pagebase = "$this->baseUri/index/categoria/$categoria/$sub";
            }
            //condicao para categorias
            $this->condition = "categoria_url = '$categoria' ";
            if ( isset( $this->uri_segment[3] ) )
            {
                $sub = $this->uri_segment[3];
                $this->condition .= "AND sub_url = '$sub'";
            }
            $this->condition .= "  AND item_show = 1";
            $this->page_active = 'categoria';
            $this->welcome();
        }
    }

    public function getTitleBar()
    {
        if ( $this->page_active == "categoria" )
        {
            $this->message_bar = "$this->categoria_title";
            if ( isset( $this->uri_segment[3] ) )
            {
                $this->message_bar = "$this->categoria_title / $this->sub_title";
            }
        }
        $this->assign( 'message_bar', $this->message_bar );
    }

    public function getMenu()
    {
        $this->menu = new Menu;
        $this->fetch( 'menu', $this->menu->get() );
        $this->fetch( 'f', $this->menu->getFooter() );
    }

    public function fillSlideShow()
    {
        $this->select()
                ->from( 'slide' )
                ->orderby( 'slide_id desc' )
                ->execute();
        if ( $this->result() )
        {
            //$this->cut( 'slide_title', 90, ' ...' );
            $this->addindex( 'slideto' );
            $this->clonekey( 'slide_foto', array( 'slide_url' ) );
            $this->preg( '/\.jpg/', '', 'slide_url' );
            $this->fetch( 'sl', $this->data );
            $this->fetch( 'sli', $this->data );
        }
    }

    public function FillMaisVistos()
    {
        $this->select('foto_url,item_id,item_url,item_title,sub_url,categoria_url')
                ->from( 'item' )
                ->join( 'sub', 'item_sub = sub_id', 'INNER' )
                ->join( 'categoria', 'sub_categoria = categoria_id', 'INNER' )
                ->join( 'foto', 'foto_item = item_id and foto.foto_pos = ( SELECT MIN( foto_pos ) FROM foto where foto_item = item_id)', 'LEFT' )
                ->where( 'item_show = 1 and item_estoque >= 1' )
                ->paginate( $this->slide_qtde_itens_mais_vistos )
                ->groupby( 'item_id' )
                ->orderby( 'item_views desc' )
                ->execute();
        if ( $this->result() )
        {
            $this->cut( 'item_title', 80, '...' );
            $this->preg( '/\.jpg/', '', 'foto_url' );
            //$this->fetch( 'mv', $this->data );
            echo json_encode($this->data);
        }
    }

    public function FillMaisNovos()
    {
        $this->select('foto_url,item_id,item_url,item_title,sub_url,categoria_url')
                ->from( 'item' )
                ->join( 'sub', 'item_sub = sub_id', 'INNER' )
                ->join( 'categoria', 'sub_categoria = categoria_id', 'INNER' )
                ->join( 'foto', 'foto_item = item_id and foto.foto_pos = ( SELECT MIN( foto_pos ) FROM foto where foto_item = item_id)', 'LEFT' )
                ->where( 'item_show = 1 and item_estoque >= 1' )
                ->paginate( $this->slide_qtde_itens_novos )
                ->groupby( 'item_id' )
                ->orderby( 'item_id desc' )
                ->execute();
        if ( $this->result() )
        {
            $this->cut( 'item_title', 80, '...' );
            $this->preg( '/\.jpg/', '', 'foto_url' );
            //$this->fetch( 'mv', $this->data );
            echo json_encode($this->data);
        }
    }

    public function getActiveCategory()
    {
        if ( isset( $this->uri_segment ) && in_array( 'categoria', $this->uri_segment ) )
        {
            $categoria = $this->uri_segment[2];
            $sub = "";
            if ( isset( $this->uri_segment[3] ) )
            {
                $sub = $this->uri_segment[3];
            }
            $this->assign( 'sub_active', $sub );
            $this->assign( 'active', $categoria );
        }
    }

    public function getCarrinho()
    {
        $cart = new Carrinho;
        if ( isset( $_SESSION['cart'] ) && count( $_SESSION['cart'] ) >= 1 )
        {
            $this->data = $_SESSION['cart'];
            $cart->getTotal();
            $this->money( 'item_preco' );
            $this->money( 'valor_total' );
            $this->cut( 'item_title', 35, '' );
            $this->assign( 'qtdeItem', count( $this->data ) );
            $this->assign( 'cartTotal', "Total R$ " . $cart->total_compra_no_frete );
            $this->fetch( 'cart', $this->data );
        }
        else
        {
            $this->assign( 'cartTotal', "O carrinho est� vazio! ;(" );
        }
    }
}
/*end file*/