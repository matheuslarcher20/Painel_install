<?php
class Thumb extends PHPFrodo
{
    public function welcome()
    {
        if ( isset( $this->uri_segment[1] ) )
        {
            $pic = "app/fotos/" . $this->uri_segment[1] . ".jpg";
            if ( !file_exists( $pic ) )
            {
                $pic = "app/images/default/nopic.jpg";
            }
            $this->helper( 'canvas' );
            $t = new Canvas;
            $t->carrega( $pic );
            $image_x = $this->uri_segment[2];
            $image_y = $this->uri_segment[3];
            if ( isset( $this->uri_segment[4] ) && $this->uri_segment[4] == 'ratio' )
            {
                $t->redimensiona( $image_x, $image_y, 'crop' );
            }
            else
            {
                $t->redimensiona( $image_x, $image_y );
            }
             $t->grava(null,90);
        }
    }

    public function slide()
    {
        if ( isset( $this->uri_segment[2] ) )
        {
            $pic = "app/fotos/slide/" . $this->uri_segment[2] . ".jpg";
            if ( !file_exists( $pic ) )
            {
                $pic = "app/images/default/nopic.jpg";
            }
            $this->helper( 'canvas' );
            $t = new Canvas;
            $t->carrega( $pic );
            $image_x = $this->uri_segment[3];
            $image_y = $this->uri_segment[4];
            if ( isset( $this->uri_segment[5] ) && $this->uri_segment[5] == 'crop' )
            {
                $t->redimensiona( $image_x, $image_y, 'crop' );
            }
            else
            {
                $t->redimensiona( $image_x, $image_y );
            }
            $t->grava(null,80);
        }
    }

}

/*end file*/