<?php

class Menu extends PHPFrodo
{

    public $menulist = array( );
    public $config_site_menu = array( );

    public function __construct()
    {
        parent:: __construct();
        $sid = new Session;
        $sid->start();
        $this->config_site_menu = ( int ) $sid->getNode( 'config_site_menu' );
    }

    public function get()
    {
        $this->select()
                ->from( 'categoria' )
                ->join( 'item', 'item_categoria = categoria_id', 'INNER' )
                ->join( 'foto', 'foto_item = item_id', 'INNER' )
                ->where( "item_show = 1" )
                ->groupby( 'categoria_id' )
                ->orderby( 'categoria_title asc' )
                ->execute();
        if ( $this->result() )
        {
            $data = $this->data;
            $this->addkey( 'categoria_small', '', 'categoria_title' );
            foreach ( $data as $k => $v )
            {
                $categoria_id = $v['categoria_id'];
                $this->select()
                        ->from( 'sub' )
                        ->join( 'item', 'item_sub = sub_id', 'INNER' )
                        ->where( "sub_categoria = $categoria_id AND item_show = 1" )
                        ->groupby( 'sub_id' )
                        ->orderby( 'sub_title asc' )
                        ->execute();
                if ( $this->result() )
                {
                    $data[$k]['sub'] = $this->data;
                    foreach ( $data[$k]['sub'] as $subs => $sub )
                    {
                        if ( $this->config_site_menu == 1 )
                        {
                            $item_id = $sub['sub_id'];
                            $this->select()->from( 'item' )->where( "item_sub = $item_id AND item_show = 1" )->execute();
                            if ( $this->result() )
                            {
                                $data[$k]['sub'][$subs]['itens'] = "<span>" . count( $this->data ) . "</span>";
                            }
                            else
                            {
                                $data[$k]['sub'][$subs]['itens'] = "<span>0</span>";
                            }
                        }
                        else
                        {
                            $data[$k]['sub'][$subs]['itens'] = "";
                        }
                    }
                }
            }
            return $data;
        }
    }

    public function getFooter()
    {    
        $this->select()
                ->from( 'area' )
                ->orderby( 'area_title asc' )
                ->execute();
        if ( $this->result() )
        {
            $aux = $this->data;
            foreach ( $aux as $k => $v )
            {
                $v = ( object ) $v;
                $aid = $v->area_id;
                $this->select()
                        ->from( 'page' )
                        ->where( "page_area = $aid" )
                        ->orderby( 'page_title asc' )
                        ->execute();
                if ( $this->result() )
                {
                    $aux[$k]['p'] = $this->data;
                }
            }
            return $aux;
        }
    }
}

/*end file*/