<?php

class Notificacao extends PHPFrodo
{

    public $config = array( );
    public $pay = array( );
    public $pReq = null;
    public $pedido_id = null;
    public $pedido_status = null;
    public $status_pat = array( '/1/', '/2/', '/3/', '/4/', '/5/', '/6/', '/7/' );
    public $status_rep = array( 'Aguardando pagamento', 'Em an�lise', 'Aprovado', 'Dispon�vel', 'Em disputa', 'Devolvida', 'Cancelada' );

    public function __construct()
    {
        parent:: __construct();
        $this->select()
                ->from( 'pay' )
                ->execute();
        if ( $this->result() )
        {
            $this->map( $this->data[0] );
        }
        else
        {
            echo 'Erro na configura��o de Pagamento';
            exit;
        }
    }

    public function welcome()
    {
        if ( isset( $_POST ) && !empty( $_POST ) )
        {
            $this->helper( 'pagseguro' );
            $type = $_POST['notificationType'];
            $code = $_POST['notificationCode'];
            //Verificamos se tipo da notifica��o � transaction
            if ( $type === 'TRANSACTION' || $type === 'transaction' )
            {
                //Informa as credenciais : Email, e TOKEN
                $credential = new PagSeguroAccountCredentials( "$this->pay_user", "$this->pay_key" );
                //Verifica as informa��es da transa��o, e retorna 
                //o objeto Transaction com todas as informa��es
                $transacao = PagSeguroNotificationService::checkTransaction( $credential, $code );
                //Retorna o objeto TransactionStatus, que vamos resgatar o valor do status
                $status = $transacao->getStatus();
                $this->pedido_status = $status->getValue();
                $this->pedido_id = $transacao->getReference();                                
                $this->update( 'pedido' )
                        ->set( array( 'pedido_pay_situacao', 'pedido_status' ), array( $this->pedido_status, $this->pedido_status ) )
                        ->where( "pedido_id = $this->pedido_id" )
                        ->execute();
                $this->notificarAdmin();
                $this->notificarCliente();
            }
        }
		else
		{
			echo 'Nenhum POST enviado para o processamento do retorno!';
		}
    }

    public function notificarAdmin()
    {
        $this->select()
                ->from( 'pedido' )
                ->join( 'cliente', 'cliente_id = pedido_cliente', 'INNER' )
                ->join( 'lista', 'lista_pedido = pedido_id', 'INNER' )
                ->where( "pedido_id = $this->pedido_id" )
                ->groupby( 'pedido_id' )
                ->execute();
        if ( $this->result() )
        {
            $this->cut( 'lista_title', 60, '' );
            $cliente_email = $this->data[0]['cliente_email'];
            $cliente_nome = $this->data[0]['cliente_nome'];
            $this->lista_title = $this->data[0]['lista_title'];
            $this->pedido_status = preg_replace( $this->status_pat, $this->status_rep, $this->pedido_status );
            $body = '<html><body>';
            $body .= '<h1 style="font-size:15px;">Status do pedido ' . $this->pedido_id . ' foi atualizado!</h1>';
            $body .= '<table style="border-color: #666; font-size:11px" cellpadding="10">';
            $body .= '<tr style="background: #fff;"><td><strong>Data:</strong> </td><td>' . date( 'd/m/Y h:s' ) . '</td></tr>';
            $body .= '<tr style="background: #eee;"><td><strong>N�mero do Pedido:</strong> </td><td>' . $this->pedido_id . '</td></tr>';
            $body .= '<tr style="background: #fff;"><td><strong>Status do Pedido:</strong> </td><td>' . $this->pedido_status . '</td></tr>';
            $body .= '<tr style="background: #eee;"><td><strong>Resumo do Pedido:</strong> </td><td>' . $this->lista_title . '...</td></tr>';
            $body .= '<tr style="background: #fff;"><td><strong>Cliente:</strong> </td><td>' . $cliente_nome . '...</td></tr>';
            $body .= '</table>';
            $body .= '<br/><br/>';
            $body .= '</body></html>';
            $m = new sendmail;
            $n = array(
                'subject' => "Status do Pedido N�$this->pedido_id Atualizado",
                'body' => $body );
            $m->sender( $n );
        }
    }

    public function notificarCliente()
    {
        $this->select()
                ->from( 'pedido' )
                ->join( 'cliente', 'cliente_id = pedido_cliente', 'INNER' )
                ->join( 'lista', 'lista_pedido = pedido_id', 'INNER' )
                ->where( "pedido_id = $this->pedido_id" )
                ->groupby( 'pedido_id' )
                ->execute();
        if ( $this->result() )
        {
            $this->cut( 'lista_title', 60, '' );
            $cliente_email = $this->data[0]['cliente_email'];
            $cliente_nome = $this->data[0]['cliente_nome'];
            $this->lista_title = $this->data[0]['lista_title'];
            $this->pedido_status = preg_replace( $this->status_pat, $this->status_rep, $this->pedido_status );
            $body = '<html><body>';
            $body .= '<h1 style="font-size:15px;">Ol� ' . $cliente_nome . ', o status do seu pedido foi atualizado!</h1>';
            $body .= '<table style="border-color: #666; font-size:11px" cellpadding="10">';
            $body .= '<tr style="background: #fff;"><td><strong>Data:</strong> </td><td>' . date( 'd/m/Y h:s' ) . '</td></tr>';
            $body .= '<tr style="background: #eee;"><td><strong>N�mero do Pedido:</strong> </td><td>' . $this->pedido_id . '</td></tr>';
            $body .= '<tr style="background: #fff;"><td><strong>Status do Pedido:</strong> </td><td>' . $this->pedido_status . '</td></tr>';
            $body .= '<tr style="background: #eee;"><td><strong>Resumo do Pedido:</strong> </td><td>' . $this->lista_title . '...</td></tr>';
            $body .= '</table>';
            $body .= '<br/><br/>';
            $body .= "<a href='$this->baseUri/cliente/'>Acesse a �rea do cliente em nosso site para ver mais detalhes.</a>";
            $body .= '<br/><br/>';
            $body .= '</body></html>';
            $m = new sendmail;
            $n = array(
                'email' => " $cliente_email",
                'subject' => "Status do Pedido N�$this->pedido_id Atualizado",
                'body' => $body );
            $m->sender( $n );
        }
    }
}

/* end file */