<?php
require_once("../system/funcoes.php");
require_once("../system/seguranca.php");
require_once("../system/config.php");


protegePagina();

if((isset($_POST["nome"])) and (isset($_POST["email"]))  ){
	        $nome = anti_sql_injection($_POST["nome"]);
			$email = anti_sql_injection($_POST["email"]);
			$celular = anti_sql_injection($_POST["celular"]);
			$senha = anti_sql_injection($_POST["senha"]);
			// mercado pago
			$valor5 = anti_sql_injection($_POST["valor5"]);
			$valor10 = anti_sql_injection($_POST["valor10"]);
			$valor15 = anti_sql_injection($_POST["valor15"]);
			$valor20 = anti_sql_injection($_POST["valor20"]);
			$valor25 = anti_sql_injection($_POST["valor25"]);
			$valor30 = anti_sql_injection($_POST["valor30"]);
			$valor50 = anti_sql_injection($_POST["valor50"]);
			$valor100 = anti_sql_injection($_POST["valor100"]);
			$valor200 = anti_sql_injection($_POST["valor200"]);
			$bancarios = anti_sql_injection($_POST["bancarios"]);

			if(strlen($senha)<6){
				echo '<script type="text/javascript">';
			    echo 	'alert("Senha muito curta!");';
			    echo	'window.location="../../home.php?page=admin/dados";';
			    echo '</script>';
			    exit;
			}


			$SQLUsuario = "SELECT * FROM usuario WHERE id_usuario = '".$_SESSION['usuarioID']."'";
            $SQLUsuario = $conn->prepare($SQLUsuario);
            $SQLUsuario->execute();

		    if(($SQLUsuario->rowCount()) > 0){
		        $eu=$SQLUsuario->fetch();

		        if($eu['tipo']=='revenda'){
		        $SQLUPUsuario = "update usuario set nome='".$nome."', email='".$email."', celular='".$celular."', senha='".$senha."',valor5='".$valor5."',valor10='".$valor10."',valor15='".$valor15."',valor20='".$valor20."',valor25='".$valor25."',valor30='".$valor30."',valor50='".$valor50."',valor100='".$valor100."',valor200='".$valor200."',dadosdeposito='".$bancarios."', atualiza_dados='1' WHERE id_usuario = '".$_SESSION['usuarioID']."'";
                $SQLUPUsuario = $conn->prepare($SQLUPUsuario);
                $SQLUPUsuario->execute();
		        }else{
				$SQLUPUsuario = "update usuario set nome='".$nome."', email='".$email."', celular='".$celular."', senha='".$senha."', atualiza_dados='1' WHERE id_usuario = '".$_SESSION['usuarioID']."'";
                $SQLUPUsuario = $conn->prepare($SQLUPUsuario);
                $SQLUPUsuario->execute();
                }
						     echo '<script type="text/javascript">';
			                 echo 	'alert("Alterado com sucesso!");';
			                 echo	'window.location="../../home.php?page=admin/dados";';
			                 echo '</script>';
			}else{
			    echo '<script type="text/javascript">';
			    echo 	'alert("Nao permitido!");';
			    echo	'window.location="../../home.php?page=admin/dados";';
			    echo '</script>';
			}

		}else{
			    echo '<script type="text/javascript">';
			    echo 	'alert("Preencha!");';
			    echo	'window.location="../../home.php?page=admin/dados";';
			    echo '</script>';
		}
?>
