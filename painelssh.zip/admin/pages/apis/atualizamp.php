<?php
require_once("../../../pages/system/seguranca.php");
require_once("../../../pages/system/config.php");
require_once("../../../pages/system/classe.ssh.php");

$valor5 = $_POST['valor5'];
$valor10 = $_POST['valor10'];
$valor15 = $_POST['valor15'];
$valor20 = $_POST['valor20'];
$valor25 = $_POST['valor25'];
$valor30 = $_POST['valor30'];
$valor50 = $_POST['valor50'];
$valor100 = $_POST['valor100'];
$valor200 = $_POST['valor200'];
$dadosdeposito = $_POST['dadosdeposito'];

            $SQLAcesso = "select * from mercadopago";
            $SQLAcesso = $conn->prepare($SQLAcesso);
            $SQLAcesso->execute();


            $SQLAcesso = "truncate mercadopago; insert into mercadopago values ('null','null','$valor5','$valor10','$valor15','$valor20','$valor25','$valor30','$valor50','$valor100','$valor200','$dadosdeposito')";
            $SQLAcesso = $conn->prepare($SQLAcesso);
            $SQLAcesso->execute();

         



echo '<script type="text/javascript">';
echo 	'alert("Autenticação Atualizada!");';
echo	'window.location="../../home.php?page=apis/gerenciar";';
echo '</script>';
?>