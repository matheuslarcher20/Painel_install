<?php


	if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit('<h1>ERROR 404</h1>Entre em contato conosco e envie detalhes.');
}

            $SQLmp = "select * from mercadopago";
            $SQLmp = $conn->prepare($SQLmp);
            $SQLmp->execute();
            $mp=$SQLmp->fetch();


if(isset($_GET['delinfo'])){
         $SQLinfo = "select * from informativo";
         $SQLinfo = $conn->prepare($SQLinfo);
         $SQLinfo->execute();

         if($SQLinfo->rowCount()>0){

         $info=$SQLinfo->fetch();


         if(unlink("../admin/pages/noticias/".$info['imagem']."")){
         $SQLinfo2 = "delete from informativo";
         $SQLinfo2 = $conn->prepare($SQLinfo2);
         $SQLinfo2->execute();

         echo '<script type="text/javascript">';
		 echo 	'alert("Informativo apagado!");';
		 echo	'window.location="home.php?page=apis/gerenciar";';
		 echo '</script>';


         }else{
         echo '<script type="text/javascript">';
		 echo 	'alert("houve algum erro durante o apagamento!");';
		 echo	'window.location="home.php?page=apis/gerenciar";';
		 echo '</script>';

         }





         }else{

         echo '<script type="text/javascript">';
		 echo 	'alert("Não foi encontrado nenhum informativo!");';
		 echo	'window.location="home.php?page=apis/gerenciar";';
		 echo '</script>';

         }



}



//echo ($valor_5,$valor_10,$valor_15,$valor_20,$valor_25,$valor_30);


?>

<!-- Main content -->
 <section class="content-header">
      <h1>
        Gerenciar Pagamentos
        <small>Gerenciamento de Pagamentos Mercado Pago</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="home.php"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li class="active">Gerenciar</li>
      </ol>
    </section>
<!-- Seção -->
<section class="content">
 <div class="row">
  <div class="col-md-7">
        <!-- left column -->
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
            <center>  <h3 class="box-title">Informe seu link de pagamento Mercado Pago</h3></center>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" name="confirmarenvio" action="pages/apis/atualizamp.php" method="post" onsubmit="return confirm('Tem certeza que deseja atualizar a autenticação (pode parar de funcionar)?');">
              <div class="box-body">

               <!--link de 5 reias-->
                  <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 5,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor5'];?>" class="form-control" name="valor5" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
				   </div>
				   
				<!--link de 10 reias-->
				   <div class="form-group">
				    <label for="inputName" class="col-sm-3 control-label">R$: 10,00</label>
				   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor10'];?>" class="form-control" name="valor10" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
                </div>
				
               <!--link de 15 reias-->
               <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 15,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor15'];?>" class="form-control" name="valor15" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   
              <!--link de 20 reias-->
			  <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 20,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor20'];?>" class="form-control" name="valor20" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   
                 <!--link de 25 reias-->
				<div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 25,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor25'];?>" class="form-control" name="valor25" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
				
				<!--link de 30 reias-->
				<div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 30,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor30'];?>" class="form-control" name="valor30" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   
			   <!--link de 50 reias-->
			   <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 50,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor50'];?>" class="form-control" name="valor50" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   
			   <!--link de 100 reias-->
			   <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 100,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor100'];?>" class="form-control" name="valor100" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   
			   <!--link de 200 reias-->
			   <div class="form-group">
                  <label for="inputName" class="col-sm-3 control-label">R$: 200,00</label>
                   <div class="append-icon">
                               <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-key"></i>
                              </div>
                  <input required="required" value="<?php echo $mp['valor200'];?>" class="form-control" name="valor200" placeholder="Exemplo: http://mpago.la/lqMa">
                </div>
                   </div>
               </div>
			   <small>*É importante informa os valores nos seus devidos lugares</small>
			   <div class="form-group">
                    <label for="inputSkills" class="col-sm-3 control-label">Dados Bancários</label>

                    <div class="form-group">
                       <div class="input-group">
                              <div class="input-group-addon">
                              <i class="fa fa-usd"></i>
                              </div>
                                <textarea name="dadosdeposito" class="form-control" placeholder="Exemplo: Conta Bradesco Para Deposito/Trânsferencia <br>
Agencia: 1548 Conta: 6468 Nome: João Paulo" rows=3 cols=20 wrap="off"><?php echo $mp['dadosdeposito'];?></textarea>

                              </div>
                    </div>
                  </div>
              <div class="box-footer">
                <center> <button type="submit" class="btn btn-primary">Enviar</button></center>
				<br>

              </div>

            </form>
       
        </div>

            <!-- left column -->
</section>
